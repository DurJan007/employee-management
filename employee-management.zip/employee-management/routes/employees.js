const express = require('express');
const router = express.Router();
const Employee = require('../models/Employee');
const Department = require('../models/Department');

// GET all employees
router.get('/', async (req, res) => {
  const employees = await Employee.find().populate('department');
  const departments = await Department.find();
  res.render('employees/index', { employees, departments });
});

// GET new employee form
router.get('/new', async (req, res) => {
  const departments = await Department.find();
  res.render('employees/new', { departments });
});

// POST create employee
router.post('/', async (req, res) => {
  await Employee.create(req.body);
  res.redirect('/employees');
});

// GET edit form
router.get('/edit/:id', async (req, res) => {
  const employee = await Employee.findById(req.params.id).populate('department');
  const departments = await Department.find();
  res.render('employees/edit', { employee, departments });
});

// POST update employee
router.post('/edit/:id', async (req, res) => {
  await Employee.findByIdAndUpdate(req.params.id, req.body);
  res.redirect('/employees');
});

// POST delete employee
router.post('/delete/:id', async (req, res) => {
  await Employee.findByIdAndDelete(req.params.id);
  res.redirect('/employees');
});

module.exports = router;