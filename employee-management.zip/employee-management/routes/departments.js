const express = require('express');
const router = express.Router();
const Department = require('../models/Department');

// GET all departments
router.get('/', async (req, res) => {
  const departments = await Department.find();
  res.render('departments/index', { departments });
});

// GET new department form
router.get('/new', (req, res) => {
  res.render('departments/new');
});

// POST create department
router.post('/', async (req, res) => {
  await Department.create(req.body);
  res.redirect('/departments');
});

// GET edit form
router.get('/edit/:id', async (req, res) => {
  const department = await Department.findById(req.params.id);
  res.render('departments/edit', { department });
});

// POST update department
router.post('/edit/:id', async (req, res) => {
  await Department.findByIdAndUpdate(req.params.id, req.body);
  res.redirect('/departments');
});

// POST delete department
router.post('/delete/:id', async (req, res) => {
  await Department.findByIdAndDelete(req.params.id);
  res.redirect('/departments');
});

module.exports = router;