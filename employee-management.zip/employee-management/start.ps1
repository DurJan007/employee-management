# Start the app in the background
Write-Host "?? Starting Employee Manager..." -ForegroundColor Green
docker compose up --build -d

# Wait a few seconds for the server to be ready
Start-Sleep -Seconds 5

# Open browser automatically
Write-Host "?? Opening http://localhost:3000 in your browser..." -ForegroundColor Cyan
Start-Process "http://localhost:3000"

Write-Host "? Done! App is running in background." -ForegroundColor Green
Write-Host "?? To stop: run 'docker compose down'" -ForegroundColor Yellow
