require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const employeeRoutes = require('./routes/employees');
const departmentRoutes = require('./routes/departments');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// Add security headers
app.use((req, res, next) => {
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';"
  );
  next();
});
// Database connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Routes
app.use('/employees', employeeRoutes);
app.use('/departments', departmentRoutes);
app.get('/', (req, res) => {
  res.render('layout', { 
    body: 'home', // tells layout.ejs to include views/home.ejs
    title: 'Home'
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});